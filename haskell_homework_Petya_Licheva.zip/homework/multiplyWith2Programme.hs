main :: IO()
main = do
	putStr "Enter a number: "
	num <- getLine
	let number = read num :: Float
	let result = number * 2
	putStr "Result: " 
	putStrLn (show result)