﻿main :: IO()
main = do 
	putStrLn "Enter down left point coordinates..."
	putStr "x1 = "
	x1 <- getLine
	putStr "y1 = "
	y1 <- getLine
	putStrLn "Enter up right point coordinates..."
	putStr "x2 = "
	x2 <- getLine
	putStr "y2 = "
	y2 <- getLine
	putStrLn "Enter a point coordinates..."
	putStr "x = "
	x <- getLine
	putStr "y = "
	y <- getLine
	let dlx = read x1 :: Int
	let dly = read y1 :: Int
	let urx = read x2 :: Int
	let ury = read y2 :: Int
	let dotX = read x :: Int
	let dotY = read y :: Int
	let result = getDotPosition dlx dly urx ury dotX dotY
	putStrLn result 
	

getDotPosition :: Int -> Int -> Int -> Int -> Int -> Int -> String
getDotPosition downLeftX downLeftY upRightX upRightY x y =
if (x > downLeftX && x < upRightX && y > downLeftY && y < upRightY) 
	then "Dot is inside the rectangle!"
else
	if (x < downLeftX || x > upRightX || y < downLeftY || y > upRightY)
		then "Dot is outside the rectangle!"
	else 
		if ((x == downLeftX && y > downLeftY && y < upRightY) || 
		(x == upRightX && y > downLeftY && y < upRightY) || 
		(y == downLeftY && x > downLeftX && x < upRightX) || 
		(y == upRightY && x > downLeftX && x < upRightX))
			then "Dot lays on any rectangle's side!"
		else 
			if ((x == downLeftX && y == downLeftY) ||
			(x == upRightX && y == upRightY) ||
			(x == (downLeftX + (upRightX - downLeftX)) && y == (downLeftY + (upRightY - downLeftY))) ||
			(x == (downLeftX + (upRightY - downLeftY)) && y == (downLeftY + (upRightX - downLeftX))))
				then "Dot is some of the rectangle's edge's coordinate!"
			else ""