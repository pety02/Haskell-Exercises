main :: IO()
main = do
	putStr "Enter radius: "
	r <- getLine
	let radius = read r :: Float
	let area = getCircleArea radius
	putStr "The circle's area is: "
	putStrLn (show area)
	
getCircleArea :: Float -> Float
getCircleArea radius = pi * (radius ^ 2)