main :: IO()
main = do
	putStr "Enter the first number: "
	line1 <- getLine
	putStr "Enter the second number: "
	line2 <- getLine
	let num1 = read line1 :: Float
	let num2 = read line2 :: Float
	let result = multiply num1 num2
	putStr "The result is: " 
	putStrLn (show result)

multiply :: Float -> Float -> Float
multiply num1 num2 = num1 * num2