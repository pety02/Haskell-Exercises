main :: IO()
main = do
	putStr "Enter a number: "
	n <- getLine
	let number = read n :: Int
	let res1 = add number
	let res2 = remove (add res1)
	putStr "Add: "
	putStr (show res1)
	putStr ", Remove: "
	putStr (show res2)

add :: Int -> Int
add num = num + 1

remove :: Int -> Int
remove num = num - 1