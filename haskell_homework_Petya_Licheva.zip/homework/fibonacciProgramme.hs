main :: IO()
main = do
	putStr "Enter a number: "
	n <- getLine
	let num = read n :: Int
	let result = fib num
	putStr "Result: "
	putStrLn (show result)

fib :: Int -> Int
fib num = if num == 1 || num == 2 then 1 else fib(num-1) + fib(num-2)