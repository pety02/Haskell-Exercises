main :: IO()
main = do
	putStr "Enter your name: "
	nm <- getLine
	putStr "Enter your family: "
	fm <- getLine
	let fullName = getFullName nm fm
	putStrLn fullName
	
getFullName :: String -> String -> String
getFullName name family = "Your full name is: " ++ name ++ " " ++ family