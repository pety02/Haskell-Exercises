main :: IO()
main = do 
	putStr "number 1: "
	num1 <- getLine
	putStr "number 2: "
	num2 <- getLine
	putStr "number 3: "
	num3 <- getLine
	let number1 = read num1 :: Int
	let number2 = read num2 :: Int
	let number3 = read num3 :: Int
	let result = maxFrom3Numbers number1 number2 number3
	putStr "Result: "
	putStrLn (show result)

maxFrom3Numbers :: Int -> Int -> Int -> Int
maxFrom3Numbers a b c = if(a > b && a > c) then a
						else if (b > a && b > c) then b
						else c