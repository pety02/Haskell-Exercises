main :: IO()
main = do
	putStr "Enter a number: "
	n <- getLine
	let number = read n :: Int
	let result = isEvenNumber number 
	putStrLn "Result: " ++ result

isEvenNumber :: Int -> String
isEvenNumber num = if (mod num 2) == 0 then "True" else "False"