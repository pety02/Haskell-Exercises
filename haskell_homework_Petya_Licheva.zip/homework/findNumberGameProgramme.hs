main :: IO()
main = do
	putStr "Enter a number for finding: "
	n <- getLine
	putStr "Suggest number: "
	n1 <- getLine
	let num1 = read n :: Int
	let num2 = read n1 :: Int
	let res = findNumber num1 num2
	if(res == "You win!") 
		then putStr res 
	else 
		putStr res
		putStr "Suggest number: "
		suggest <- getLine
		let number = read suggest :: Int
		findNumber num1 number

findNumber :: Int -> Int -> String
findNumber num guessNum = if(guessNum == num) then "You win!" else
	if(guessNum > num) then "Too high!" else 
	if (guessNum < num) then "Too low!"