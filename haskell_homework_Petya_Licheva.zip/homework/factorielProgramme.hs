main :: IO()
main = do
	putStr "Enter a number: "
	n <- getLine
	let num = read n :: Int
	let result = fact num
	putStr "Result: "
	putStrLn (show result) 

fact :: Int -> Int
fact num = if num == 1 then 1 else num * fact (num - 1)